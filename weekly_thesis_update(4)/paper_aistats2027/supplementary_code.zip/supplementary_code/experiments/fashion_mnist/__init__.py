"""Fashion-MNIST experiment entrypoints."""
